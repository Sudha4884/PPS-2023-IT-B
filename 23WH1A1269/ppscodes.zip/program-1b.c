//Working on incerement and decerement operator
#include<stdio.h>
int main ()
{
    int a = 10,b = 7;
    float c = 10.7, d = 107.01;
    printf("++a = %d \n",++a);
    printf("--b = %d \n",--b);
    printf("++c = %d \n",++c);
    printf("--d = %d \n",--d);
}