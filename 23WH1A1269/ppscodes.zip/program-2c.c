#include<stdio.h>

int main() {
    
  // character variable
  char alphabet = 'a';
  printf("Character Value: %c\n", alphabet);

  // assign character value to integer variable
  int number = alphabet;
  printf("Integer Value: %d", number);
     
  return 0;
}