//Working on arithmetic operator
#include<stdio.h>
int main()
{
    int a = 7,b = 10,c;
    c=a+b;
    printf("a+b = %d \n",c);
    c=a-b;
    printf("a-b = %d \n",c);
    c=a*b;
    printf("a*b = %d \n",c);
    c=a/b;
    printf("a/b = %d \n",c);
    c=a%b;
    printf("Reminder when a is divided by b = %d \n",c);
}
