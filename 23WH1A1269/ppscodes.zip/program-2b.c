#include<stdio.h>

int main() {

  // create a double variable
  double value = 4150.12;
  printf("Double Value: %.2lf\n", value);
 
  // convert double value to integer
  int number = value;
  printf("Integer Value: %d", number);
    
  return 0;
}