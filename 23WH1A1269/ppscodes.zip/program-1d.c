//Working of relationl operators
#include<stdio.h>
int main()
{
    int a = 7,b = 10;
    printf("%d == %d is %d \n",a,b,a == b);
    printf("%d > %d is %d \n",a,b,a > b);
    printf("%d < %d is %d \n",a,b,a < b);
    printf("%d >= %d is %d \n",a,b,a >= b);
    printf("%d <= %d is %d \n",a,b,a <= b);
    printf("%d >> %d is %d \n",a,b,a >> b);
    printf("%d << %d is %d \n",a,b,a << b);
    printf("%d != %d is %d \n",a,b,a != b);
}