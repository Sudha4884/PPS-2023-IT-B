#include <stdio.h>
int main() 
{
    
  int number = 34.78;
  printf("%d", number);
    
  return 0;
}

