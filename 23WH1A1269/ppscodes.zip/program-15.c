
#include <bits/stdc++.h>
using namespace std;

double sum(int x, int n)
{
	double i, total = 1.0, multi = x;
	for (i = 1; i <= n; i++)
	{
		total = total + multi / i;
		multi = multi * x;
	}
	return total;
}


{
	int x = 2;
	int n = 5;
	cout << fixed << setprecision(2) << sum(x, n);
	return 0;
}


